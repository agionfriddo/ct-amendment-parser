const SENATE_AMENDMENTS_TABLE = "senate_amendments";
const HOUSE_AMENDMENTS_TABLE = "house_amendments";
const REGION = "us-east-1";

module.exports = { SENATE_AMENDMENTS_TABLE, HOUSE_AMENDMENTS_TABLE, REGION };
